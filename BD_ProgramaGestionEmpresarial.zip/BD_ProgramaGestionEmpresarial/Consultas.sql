select * from Clientes;
select * from Persona;
select * from Proyectos;
select * from Registros;
select * from Empleados;