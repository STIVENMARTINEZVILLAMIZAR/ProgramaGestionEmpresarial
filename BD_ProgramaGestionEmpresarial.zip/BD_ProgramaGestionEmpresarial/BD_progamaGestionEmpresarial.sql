Create Database ProgramaGestionEmpresarial;

Use  ProgramaGestionEmpresarial;

/*drop database ProgramaGestionEmpresarial;*/

    create table Persona(

     id_Persona int primary key,
     nombre varchar(50),
     apellido varchar(50),
     edad int,
     tipoCargo varchar(50),
     sexo char(1)
    );

    create table Empleados(
    id_empleado int primary key,
    nombre varchar(50),
    apellido varchar(50),
    tipoCargo varchar(50),
    activo boolean
    );

    create table Clientes(
    id_Clientes int primary key,
    nombre varchar(50),
    edad int,
    tipoCliente varchar(50)
    );

    create table Proyectos(

    id_Proyectos int primary key,
    nombreProyecto varchar(100),
    horasTrabajo Decimal(5,2),
    costoHora Decimal (10,2),
    total Decimal(10,2),
    id_Clientes Int,
    FOREIGN KEY (id_Clientes) REFERENCES Clientes(id_Clientes)
    );

    create table Registros(

    id_Registros int primary key,
    tablaAfectada varchar(50),
    fecha DATETIME
    );